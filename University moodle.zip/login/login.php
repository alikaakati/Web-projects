<?php
session_start();
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login page</title>
<link href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="loginpage.css">
</head>
<body>


<!-- Modal HTML -->
<div id="myModal" style="margin-top: 20vh;">
	<div class="modal-dialog modal-login">
		<div class="modal-content">
			<div class="modal-header">
				<div class="avatar">
					<img src="user-icon.png" alt="user">
				</div>				
				<h4 class="modal-title">Member Login</h4>	

			</div>
			<div class="modal-body">
				<form action="checklogin.php" method="post">
					<div class="form-group">
						<input type="text" class="form-control" name="username" placeholder="Username" required="required" style="margin-bottom: 3px">
						<span><?php echo $_SESSION['usernameerror']; ?></span>	
					</div>
					<div class="form-group">
						<input type="password" class="form-control" name="password" placeholder="Password" required="required">	
						<span><?php echo $_SESSION['passworderror']; ?></span>	
					</div>        
					<div class="form-group">
						<button type="submit" class="btn btn-primary btn-lg btn-block login-btn">Login</button>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				No account?<br><a href="http://localhost:8012/moodleUSAL/register/register.php" style="color: black;text-decoration: none;cursor: pointer"> Register</a>
			</div>
		</div>
	</div>
</div>     
</body>
</html>                            