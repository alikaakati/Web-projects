<?php
session_start();
include "../conn.php";
$_SESSION['usernameerror'] = "";
$_SESSION['passworderror'] = "";
$username = $_POST['username'];
$password = $_POST['password'];
$_SESSION['username'] = "";
$_SESSION['firstname'] = "";
$_SESSION['lastname'] = "";
$_SESSION['phone'] = "";
$_SESSION['mID'] = "";


if($username == ''){
        $_SESSION['usernameerror']="Please fill the username field !";
        header('Location:http://localhost:8012/moodleUSAL/login/login.php');
        exit();
}


if($password == ''){
        $_SESSION['passworderror']="Please fill the password field !";
        header('Location:http://localhost:8012/moodleUSAL/login/login.php');
        exit();
}


$sql = "SELECT * FROM students WHERE sUsername = '$username' AND sPassword='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $_SESSION['username'] = $row['sUsername'];
        $_SESSION['firstname'] = $row['sFirstname'];
        $_SESSION['lastname'] = $row['sLastname'];
        $_SESSION['phone'] = $row['sPhone'];
        $_SESSION['mID'] = $row['mID'];
        header('Location:http://localhost:8012/moodleUSAL/moodle/student/index.php');
        exit();        
    }
}



$sql = "SELECT * FROM teachers WHERE tUsername = '$username' AND tPassword='$password'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $_SESSION['username'] = $row['tUsername'];
        $_SESSION['firstname'] = $row['tFirstname'];
        $_SESSION['lastname'] = $row['tLastname'];
        $_SESSION['phone'] = $row['tPhone'];
        $_SESSION['mID'] = $row['mID'];

        header('Location:http://localhost:8012/moodleUSAL/moodle/teacher/index.php');
        exit();        
    }
}

$sql = "SELECT aID,username, password,firstname,lastname,phone FROM admin WHERE username = '$username' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $_SESSION['username'] = $row['username'];
        $_SESSION['firstname'] = $row['firstname'];
        $_SESSION['lastname'] = $row['lastname'];
        $_SESSION['phone'] = $row['phone'];
        $_SESSION['mID'] = $row['mID'];

        header('Location:http://localhost:8012/moodleUSAL/moodle/admin/index.php');
        exit();        
    }
}

else{
        $_SESSION['usernameerror']="User does not exist !";
        header('Location:http://localhost:8012/moodleUSAL/login/login.php');
        exit();

}

?>