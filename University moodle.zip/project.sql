-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2020 at 07:27 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aID` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aID`, `username`, `password`, `firstname`, `lastname`, `phone`) VALUES
(2, 'admin', '123', 'admin', 'admin', 999999);

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attID` int(11) NOT NULL,
  `sID` int(11) DEFAULT NULL,
  `cID` int(11) DEFAULT NULL,
  `day` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`attID`, `sID`, `cID`, `day`) VALUES
(100000, 1008, 15000125, '2020-02-05'),
(100001, 1008, 15000126, '2020-02-06'),
(100002, 1010, 15000125, '2020-02-05'),
(100003, 1010, 15000126, '2020-02-07');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `cID` int(11) NOT NULL,
  `cName` varchar(255) DEFAULT NULL,
  `cSection` varchar(255) DEFAULT NULL,
  `cCredits` int(11) DEFAULT NULL,
  `at` time NOT NULL DEFAULT current_timestamp(),
  `toTime` time NOT NULL DEFAULT current_timestamp(),
  `days` varchar(255) NOT NULL,
  `mID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`cID`, `cName`, `cSection`, `cCredits`, `at`, `toTime`, `days`, `mID`) VALUES
(15000125, 'Introduciton to programming', 'A', 3, '09:30:00', '11:00:00', 'Monday - Tuesday', 12),
(15000126, 'Intro to web', 'A', 3, '11:00:00', '12:30:00', 'Wednesday and Thursday', 12),
(15000127, 'Intro to business', 'A', 3, '09:00:00', '11:00:00', 'Monday and Wednesday', 13);

-- --------------------------------------------------------

--
-- Table structure for table `enrolled`
--

CREATE TABLE `enrolled` (
  `sID` int(11) DEFAULT NULL,
  `cID` int(11) DEFAULT NULL,
  `mID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enrolled`
--

INSERT INTO `enrolled` (`sID`, `cID`, `mID`) VALUES
(1008, 15000125, 12),
(1008, 15000126, 12);

-- --------------------------------------------------------

--
-- Table structure for table `grade`
--

CREATE TABLE `grade` (
  `gID` int(11) NOT NULL,
  `cID` int(11) DEFAULT NULL,
  `sID` int(11) DEFAULT NULL,
  `examName` varchar(255) DEFAULT NULL,
  `percentage` int(11) NOT NULL,
  `grade` int(11) DEFAULT NULL,
  `takenAt` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `grade`
--

INSERT INTO `grade` (`gID`, `cID`, `sID`, `examName`, `percentage`, `grade`, `takenAt`) VALUES
(5003, 15000125, 1008, 'Test 1', 25, 95, '2020-02-05'),
(5004, 15000126, 1008, 'Test 1', 25, 90, '2020-02-07'),
(5005, 15000125, 1008, 'Midterm', 40, 85, '2020-02-12');

-- --------------------------------------------------------

--
-- Table structure for table `major`
--

CREATE TABLE `major` (
  `mID` int(11) NOT NULL,
  `mName` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `major`
--

INSERT INTO `major` (`mID`, `mName`) VALUES
(12, 'Computer Science'),
(13, 'Business');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `messageID` int(11) NOT NULL,
  `senderUsername` varchar(255) DEFAULT NULL,
  `receiverUsername` varchar(255) DEFAULT NULL,
  `subject` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`messageID`, `senderUsername`, `receiverUsername`, `subject`, `content`, `at`) VALUES
(10000, 'm.elhajj', 'alikaakati', 'About the FYP', 'lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum lorem ipsilum ', '2020-01-29 09:21:46'),
(10002, 'alikaakati', 'admin', 'This is a test message', 'This is a test message to check if the messaging system i built is working correctly ! :)', '2020-02-02 11:00:08'),
(10003, 'admin', 'MohamadNasir', 'Hello', 'Hello Mohamad Nasir :)', '2020-02-02 11:18:42');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `sID` int(11) NOT NULL,
  `sUsername` varchar(255) DEFAULT NULL,
  `sPassword` varchar(255) DEFAULT NULL,
  `sFirstname` varchar(255) DEFAULT NULL,
  `sLastname` varchar(255) DEFAULT NULL,
  `sPhone` int(11) DEFAULT NULL,
  `mID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`sID`, `sUsername`, `sPassword`, `sFirstname`, `sLastname`, `sPhone`, `mID`) VALUES
(1008, 'alikaakati', '', 'Ali', 'Kaakati', 76849448, 12),
(1009, 'mhmdnasir', '', 'mhmd', 'nasir', 71016500, 12),
(1010, 'mhmdalikoeik', '', 'mhmd', 'ali', 71451515, 12),
(1012, 'testuser', 'password1', 'test', 'user', 76849448, 12);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `tID` int(11) NOT NULL,
  `tUsername` varchar(255) DEFAULT NULL,
  `tPassword` varchar(255) DEFAULT NULL,
  `mID` int(11) DEFAULT NULL,
  `tFirstname` varchar(255) DEFAULT NULL,
  `tLastname` varchar(255) DEFAULT NULL,
  `tPhone` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`tID`, `tUsername`, `tPassword`, `mID`, `tFirstname`, `tLastname`, `tPhone`) VALUES
(2011, 'm.elhajj', '123456789', 12, 'Mohamad', 'ElHajj', 71822151);

-- --------------------------------------------------------

--
-- Table structure for table `teaches`
--

CREATE TABLE `teaches` (
  `tID` int(11) DEFAULT NULL,
  `cID` int(11) DEFAULT NULL,
  `mID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teaches`
--

INSERT INTO `teaches` (`tID`, `cID`, `mID`) VALUES
(2011, 15000125, 12),
(2011, 15000126, 12);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aID`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attID`),
  ADD KEY `sID` (`sID`),
  ADD KEY `cID` (`cID`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`cID`),
  ADD KEY `courses_ibfk_1` (`mID`);

--
-- Indexes for table `enrolled`
--
ALTER TABLE `enrolled`
  ADD KEY `sID` (`sID`),
  ADD KEY `cID` (`cID`),
  ADD KEY `mID` (`mID`);

--
-- Indexes for table `grade`
--
ALTER TABLE `grade`
  ADD PRIMARY KEY (`gID`),
  ADD KEY `grade_ibfk_1` (`cID`),
  ADD KEY `grade_ibfk_2` (`sID`);

--
-- Indexes for table `major`
--
ALTER TABLE `major`
  ADD PRIMARY KEY (`mID`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`messageID`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`sID`),
  ADD KEY `students_ibfk_1` (`mID`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`tID`),
  ADD KEY `teachers_ibfk_1` (`mID`);

--
-- Indexes for table `teaches`
--
ALTER TABLE `teaches`
  ADD KEY `teaches_ibfk_1` (`mID`),
  ADD KEY `teaches_ibfk_2` (`tID`),
  ADD KEY `teaches_ibfk_3` (`cID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100004;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `cID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15000128;

--
-- AUTO_INCREMENT for table `grade`
--
ALTER TABLE `grade`
  MODIFY `gID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5006;

--
-- AUTO_INCREMENT for table `major`
--
ALTER TABLE `major`
  MODIFY `mID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `messageID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10004;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `sID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1013;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `tID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2012;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`sID`) REFERENCES `students` (`sID`),
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`cID`) REFERENCES `courses` (`cID`);

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`mID`) REFERENCES `major` (`mID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `enrolled`
--
ALTER TABLE `enrolled`
  ADD CONSTRAINT `enrolled_ibfk_1` FOREIGN KEY (`sID`) REFERENCES `students` (`sID`),
  ADD CONSTRAINT `enrolled_ibfk_2` FOREIGN KEY (`cID`) REFERENCES `courses` (`cID`),
  ADD CONSTRAINT `enrolled_ibfk_3` FOREIGN KEY (`mID`) REFERENCES `major` (`mID`);

--
-- Constraints for table `grade`
--
ALTER TABLE `grade`
  ADD CONSTRAINT `grade_ibfk_1` FOREIGN KEY (`cID`) REFERENCES `courses` (`cID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `grade_ibfk_2` FOREIGN KEY (`sID`) REFERENCES `students` (`sID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`mID`) REFERENCES `major` (`mID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teachers`
--
ALTER TABLE `teachers`
  ADD CONSTRAINT `teachers_ibfk_1` FOREIGN KEY (`mID`) REFERENCES `major` (`mID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teaches`
--
ALTER TABLE `teaches`
  ADD CONSTRAINT `teaches_ibfk_1` FOREIGN KEY (`mID`) REFERENCES `major` (`mID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `teaches_ibfk_2` FOREIGN KEY (`tID`) REFERENCES `teachers` (`tID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `teaches_ibfk_3` FOREIGN KEY (`cID`) REFERENCES `courses` (`cID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
