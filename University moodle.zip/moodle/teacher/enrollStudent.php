<?php
session_start();
include '../../conn.php';
$_SESSION['errorMsg'] = "";
$username = $_SESSION['username'];
$firstname = $_SESSION['firstname'];
$lastname = $_SESSION['lastname'];
$phone = $_SESSION['phone'];
$mID = $_SESSION['mID'];
$sql = "SELECT * FROM major WHERE mID = '$mID'";
$result = $conn->query($sql);
$mName = "";
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
$mName = $row['mName'];
        }
    }

$sql = "SELECT tID from teachers WHERE tUsername = '$username'";
$result = $conn->query($sql);
$tID = "";
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
$tID = $row['tID'];
        }
    }

?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Pure CSS Fly In Sidebar Nav</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
<link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./style.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>

</head>
<body>
<!-- partial:index.partial.html -->
<section class="app" style="width:17.5vw;margin-right:3vh;float: left">
  <aside class="sidebar">
      <header><h1>
        <?php echo "Welcome ".$_SESSION['firstname']; ?></h1>
      </header>
    <nav class="sidebar-nav">
 
      <ul>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="index.php"><span>View account</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="courses.php"><span class="">My courses</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="grades.php"><span class="">My grades</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="schedule.php"><span class="">My schedule</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="messages.php"><span class="">My messages</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="../../index.php"><span class="">Log out</span></a>
        </li>
      </ul>
    </nav>
  </aside>
</section>
<!-- partial -->

<div style="width: 80vw;height: 7vh;float: left;margin-left: -1.5vw;padding-left: 30vw;margin-top: 3vh;">
  <?php
  echo "<h3 style='margin-left:-0.5vw;font-size:1.5vw'>".$_SESSION['errorMsg']."</h3>";
  ?>
  <form method="POST" action="" style="margin-top: 2vw;">
  <select name="student" class="form-control active-cyan-4 mb-4" style="width: 17vw;margin-bottom: 1vw;">
      <?php 
      $sql = "SELECT * FROM students s,teachers t WHERE s.mID = t.mID";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
      echo "<option value='".$row['sID']."'>".$row['sUsername']."</option>";
      }
      }
      ?>
  </select>
    <select name="course" class="form-control active-cyan-4 mb-4" style="width: 17vw;margin-bottom: 1vw;">
      <?php 
      $sql = "SELECT * FROM courses c,teachers t,teaches te WHERE te.mID = t.mID AND te.tID = t.tID AND c.cID = te.cID";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
      echo "<option value='".$row['cID']."'>".$row['cName']." - ".$row['cID']."</option>";
      }
      }
      ?>
  </select>
  <button type="submit" name="submit" class="form-control active-cyan-4 mb-4 btn-primary" style="width: 17vw;">Submit</button>
</form>
<?php
if(isset($_POST['submit'])){
  $student = $_POST['student'];
  $course = $_POST['course'];
  $sql = "INSERT INTO enrolled(sID,cID,mID)
  VALUES ('$student','$course','$mID')";
          if ($conn->query($sql) === TRUE) {
            $_SESSION['errorMsg'] = "Student Enrolled succesfully !";
            header('Location:http://localhost:8012/moodleUSAL/moodle/teacher/courses.php');
        }
}

?>
</div>
</div>
</body>
</html>