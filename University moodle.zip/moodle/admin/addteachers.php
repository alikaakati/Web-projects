<?php
session_start();
include '../../conn.php';
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Pure CSS Fly In Sidebar Nav</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
<link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./style.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>

</head>
<body>
<!-- partial:index.partial.html -->
<section class="app" style="width:17.5vw;margin-right:3vh;float: left">
  <aside class="sidebar">
      <header><h1>
        <?php echo "Welcome ".$_SESSION['firstname']; ?></h1>
      </header>
    <nav class="sidebar-nav">
 
      <ul>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="index.php"><span>View account</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="students.php"><span class="">Students</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="teachers.php"><span class="">Teachers</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="courses.php"><span class="">Courses</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="messages.php"><span class="">My messages</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="../../index.php"><span class="">Log out</span></a>
        </li>
      </ul>
    </nav>
  </aside>
</section>
<!-- partial -->


<div style="width: 80vw;height: 7vh;float: left;margin-left: -1.5vw;padding-left: 30vw;margin-top: 3vh;">
  <?php
  echo "<h3 style='margin-left:-0.5vw;font-size:1.5vw'>".$_SESSION['errorMsg']."</h3>";
  ?>
  <form method="POST" action="" style="margin-top: 2vw;">
  <input class="form-control active-cyan-4 mb-4" type="text" placeholder="Username" aria-label="Search" style="width: 17vw;display: block;margin-bottom: 1vw;height: 5vh;" name="sUsername">
  <input class="form-control active-cyan-4 mb-4" type="text" placeholder="Firstname" aria-label="Search" name="sFirstname" style="width: 17vw;display: block;margin-bottom: 1vw;height: 5vh;">
  <input class="form-control active-cyan-4 mb-4" type="text" placeholder="Lastname" aria-label="Search" name="sLastname" style="width: 17vw;display: block;margin-bottom: 1vw;height: 5vh;">
  <input class="form-control active-cyan-4 mb-4" type="text" placeholder="Phone" aria-label="Search" name="sPhone" style="width: 17vw;display: block;margin-bottom: 1vw;height: 5vh;">
  <select name="major" class="form-control active-cyan-4 mb-4" style="width: 17vw;margin-bottom: 1vw;">
      <?php 
      $sql = "SELECT * FROM major m";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
      echo "<option value='".$row['mID']."'>".$row['mName']."</option>";
      }
      }
      ?>
  </select>
  <button type="submit" name="submit" class="form-control active-cyan-4 mb-4 btn-primary" style="width: 17vw;">Submit</button>
    
    <?php
    if(isset($_POST['submit'])){
      $_SESSION['errorMsg'] ="";
    $username = $_POST['sUsername'];
    $firstname = $_POST['sFirstname'];
    $lastname = $_POST['sLastname'];
    $phone = $_POST['sPhone'];
    $major = $_POST['major'];
    if($username == "" or $firstname == "" or $lastname == "" ){
        $_SESSION['errorMsg'] = "Please fill in all the input fields !";
        exit();
        $sql = "SELECT * FROM teachers t";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
        $_SESSION['errorMsg'] = "Username is already in use";
        exit();
        }

    }
    else{
        $sql = "INSERT INTO teachers(tUsername,tPassword,tFirstname,tLastname,tPhone,mID)
        VALUES ('$username','123456789','$firstname','$lastname',$phone,'$major')";
        if ($conn->query($sql) === TRUE) {
            $_SESSION['errorMsg'] = "Teacher added succesfully !";
            header('http://localhost:8012/moodleUSAL/moodle/admin/teachers.php#');
        }
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

    }
    }

     ?>
  






</div>
</form>



</body>
</html>
