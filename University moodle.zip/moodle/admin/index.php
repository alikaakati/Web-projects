<?php
session_start();
include '../../conn.php';
$username = $_SESSION['username'];
$firstname = $_SESSION['firstname'];
$lastname = $_SESSION['lastname'];
$phone = $_SESSION['phone'];
$mID = $_SESSION['mID'];
$sql = "SELECT * FROM major WHERE mID = '$mID'";
$result = $conn->query($sql);
$mName = "";
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
$mName = $row['mName'];
        }
    }
$sql = "SELECT aID from admin WHERE username = '$username'";
$result = $conn->query($sql);
$sID = "";
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
$sID = $row['aID'];
        }
    }
?>
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Pure CSS Fly In Sidebar Nav</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
<link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./style.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>

</head>
<body>
<!-- partial:index.partial.html -->
<section class="app" style="width:17.5vw;margin-right:3vh;float: left">
  <aside class="sidebar">
      <header><h1>
        <?php echo "Welcome ".$_SESSION['firstname']; ?></h1>
      </header>
    <nav class="sidebar-nav">
 
      <ul>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="index.php"><span>View account</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="students.php"><span class="">Students</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="teachers.php"><span class="">Teachers</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="courses.php"><span class="">Courses</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="messages.php"><span class="">My messages</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="../../index.php"><span class="">Log out</span></a>
        </li>
      </ul>
    </nav>
  </aside>
</section>
<!-- partial -->
<div class="col-md-offset-1" style="width: 80vw;float: left;margin-left: -1.5vw;margin-top: 3vh;">
  <img src="../../avatar.png" style="margin-left: 30vw;border-bottom: 1px solid black;">
  <br>
  <div style="margin-left: 28vw;justify-content: center;">
  <h2>ID : <?php echo $sID?></h2>
  <h2>Full name : <?php echo $firstname . " " .$lastname; ?></h2> 
  <h2>Username : <?php echo $username?></h2>
  <h2>Phone : <?php echo $phone?></h2>
  </div>   
</div>   
</body>
</html>
