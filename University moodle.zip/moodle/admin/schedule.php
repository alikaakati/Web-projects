<?php
session_start();
include '../../conn.php';
$result = mysqli_query($conn,"SELECT * FROM students LIMIT 10");
if (!$result) {
printf("Error: %s\n", mysqli_error($conn));
exit();
}

//show artist data in table
echo "<table><th>BadNoise Artists</th>";
while($row = mysqli_fetch_array($result)){
    echo "<tr><td>" . $row['sFirstname'] . "</td><td>" . $row['sLastname'] . "</td><td><button id='" . $row['sID'] . "'>Get External Content</button></td></tr>" ;
}
echo "</table>";
mysqli_close($conn);
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("button").click(function(){
    var sID = $(this).attr('id');
    $("#div1").text("demo_test" + sID + ".txt");
  });
});
</script>

</body>
</html>