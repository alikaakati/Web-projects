<?php
session_start();
include '../../conn.php';
$username = $_SESSION['username'];
$firstname = $_SESSION['firstname'];
$lastname = $_SESSION['lastname'];
$phone = $_SESSION['phone'];
$mID = $_SESSION['mID'];
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Pure CSS Fly In Sidebar Nav</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
<link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./style.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>

</head>
<body>
<!-- partial:index.partial.html -->
<section class="app" style="width:17.5vw;margin-right:3vh;float: left">
  <aside class="sidebar">
      <header><h1>
        <?php echo "Welcome ".$_SESSION['firstname']; ?></h1>
      </header>
    <nav class="sidebar-nav">
 
      <ul>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="index.php"><span>View account</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="students.php"><span class="">Students</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="teachers.php"><span class="">Teachers</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="courses.php"><span class="">Courses</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="messages.php"><span class="">My messages</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="../../index.php"><span class="">Log out</span></a>
        </li>
      </ul>
    </nav>
  </aside>
</section>

<div class="col-md-offset-1" style="width: 80vw;float: left;margin-left: -1.5vw;margin-top: 3vh;">
<form style="margin-left: 4vw;" id="msgForm" method="POST" action="">
  <button class="btn btn-primary" style="float: right;width: 6vw;font-size: 1.2vw;" type="submit" name="submit">Send</button>
  <div style="border-bottom: 1px solid black;height: 7vh;">
  <label style="float: left;margin-left: 10vw;margin-top: 2vh;">From</label>
  <?php echo "
  <input class='form-control active-cyan-4 mb-4' type='text' placeholder='".$username."' aria-label='Search' style='width: 17vw;display: block;margin-bottom: 1vw;height: 5vh;float: right;margin-right: 10vw;'' name='senderUsername' readonly='true'>
  ";
  ?>
  </div>
  <div style="border-bottom: 1px solid black;height: 7vh;">
  <label style="float: left;margin-left: 10vw;margin-top: 2vh;">To</label>
  <select class="form-control active-cyan-4 mb-4" style="width: 17vw;display: block;margin-bottom: 1vw;height: 5vh;float: right;margin-right: -17vw;
  margin-top: 1vh;" name="receiverUsername">
        <?php 
      $sql = "SELECT sUsername FROM students";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
      echo "<option value='".$row['sUsername']."'>".$row['sUsername']."</option>";
      }
      }
      $sql = "SELECT tUsername FROM teachers";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
      echo "<option value='".$row['tUsername']."'>".$row['tUsername']."</option>";
      }
      }
      $sql = "SELECT username FROM admin";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
      echo "<option value='".$row['username']."'>".$row['username']."</option>";
      }
      }
      ?>
    </select>
  </div>
  <input class="form-control active-cyan-4 mb-4" type="text" placeholder="Subject" name="subject" style="margin-bottom: 2vh;font-size: 1vw;border:0px;border-bottom: 1px solid black;height: 5vh;padding-left: 10vw;">

</form>
<textarea rows="4" cols="50" name="content" form="msgForm" style="width: 70vw;margin-left: 4vw;height: 60vh;">
</textarea>

<?php echo "<h3 style='margin-left:3.5vw'>".$_SESSION['errorMsg']."</h3>"; ?>
</div>
<?php
if(isset($_POST['submit'])){
$senderUsername = $username;
$receiverUsername = $_POST['receiverUsername'];
$subject = $_POST['subject'];
$content = $_POST['content'];
    if($senderUsername == "" or $receiverUsername == "" or $content == "" ){
        $_SESSION['errorMsg'] = "Please fill all the input fields !";
        exit();
    }
    else{
        $sql = "INSERT INTO messages(senderUsername,receiverUsername,subject,content)
        VALUES ('$senderUsername','$receiverUsername','$subject','$content')";
        if ($conn->query($sql) === TRUE) {
            $_SESSION['errorMsg'] = "Message Sent succesfully !";
            header('Location:http://localhost:8012/moodleUSAL/moodle/student/sendMessage.php');
            exit();
        }
        else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

    }

}
?>
</body>
</html>