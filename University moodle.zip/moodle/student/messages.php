<?php
session_start();
include '../../conn.php';
$username = $_SESSION['username'];
$firstname = $_SESSION['firstname'];
$lastname = $_SESSION['lastname'];
$phone = $_SESSION['phone'];
$mID = $_SESSION['mID'];
?>

<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen - Pure CSS Fly In Sidebar Nav</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
<link href='https://fonts.googleapis.com/css?family=Lato:400,300,700' rel='stylesheet' type='text/css'><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
<link rel="stylesheet" href="./style.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>

</head>
<body>
<!-- partial:index.partial.html -->
<section class="app" style="width:17.5vw;margin-right:3vh;float: left">
  <aside class="sidebar">
      <header><h1>
        <?php echo "Welcome ".$_SESSION['firstname']; ?></h1>
      </header>
    <nav class="sidebar-nav">
 
      <ul>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="index.php"><span>View account</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="courses.php"><span class="">My courses</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="grades.php"><span class="">My grades</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="schedule.php"><span class="">My schedule</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="messages.php"><span class="">My messages</span></a>
        </li>
        <li style="border-bottom: 1px solid #60c7c1;">
          <a href="../../index.php"><span class="">Log out</span></a>
        </li>
      </ul>
    </nav>
  </aside>
</section>
<!-- partial -->
<div class="col-md-offset-1" style="width: 80vw;float: left;margin-left: -1.5vw;margin-top: 3vh;">
  <div class="panel panel-default panel-table">
    <div class="panel-heading">
      <div class="row">
        <div class="col col-xs-6">
          <h3 class="panel-title">My Messages</h3>
        </div>
      </div>
    </div>

  <div class="panel-body">
  <a href="sendMessage.php">
  <button class="btn" style="margin-bottom: 1vh;width: 3vw;height: 3vw;background-color: #60c7c1;color: white; ">
    <em class="fa fa-plus"></em>
  </button>
</a>
    <table class="table table-striped table-bordered table-list">
      <thead>
        <tr>
            <th class="hidden-xs" width="10%">Sent From</th>
            <th width="10%">Sent At</th>
            <th width="30%">Subject</th>
            <th>Content</th>
        </tr> 
      </thead>
      <tbody>

        <?php
            $sql = "SELECT * FROM messages WHERE receiverUsername = '$username'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row['senderUsername']."</td>";
                    echo "<td>".$row['at']."</td>";
                    echo "<td>".$row['subject']."</td>";
                    echo "<td>".$row['content']."</td>";
                    
                    ;
                }
            }
?>        
      </tbody>
    </table>

</div>
</div>  

  <div class="panel panel-default panel-table">
    <div class="panel-heading">
      <div class="row">
        <div class="col col-xs-6">
          <h3 class="panel-title">Sent Messages</h3>
        </div>
      </div>
    </div>

  <div class="panel-body">
  <a href="sendMessage.php">
</a>
    <table class="table table-striped table-bordered table-list">
      <thead>
        <tr>
            <th class="hidden-xs" width="10%">Sent From</th>
            <th width="10%">Sent At</th>
            <th width="30%">Subject</th>
            <th>Content</th>
        </tr> 
      </thead>
      <tbody>

        <?php
            $sql = "SELECT * FROM messages WHERE senderUsername = '$username'";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>".$row['senderUsername']."</td>";
                    echo "<td>".$row['at']."</td>";
                    echo "<td>".$row['subject']."</td>";
                    echo "<td>".$row['content']."</td>";
                    
                    ;
                }
            }
?>        
      </tbody>
    </table>

</div>
</div>         
</div>   
</body>
</html>
