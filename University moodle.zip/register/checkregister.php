<?php
session_start();
include "../conn.php";
$username = $_POST['username'];
$password = $_POST['password'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$phone = $_POST['phone'];
$mID = $_POST['major'];

$sql = "SELECT * FROM students";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    if($username === $row['sUsername']){
        $_SESSION['error'] = "Username already in use";
        header("Location:http://localhost:8012/moodleUSAL/register/register.php");
        exit();
    }
    }
}


$sql = "INSERT INTO students (sUsername, sPassword, sFirstname, sLastname , sPhone ,mID)
VALUES ('$username', '$password', '$firstname' ,'$lastname' ,'$phone','$mID')";
if ($conn->query($sql) === TRUE) {
$_SESSION['username'] = $username;
$_SESSION['firstname'] = $firstname;
$_SESSION['lastname'] = $lastname;
$_SESSION['phone'] = $phone;
$_SESSION['mID'] = $mID;
header("Location:http://localhost:8012/moodleUSAL/moodle/student/index.php");

} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

?>