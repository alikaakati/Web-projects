Hello,
To View how the code works
Please create a database using the db.sql file
Then test the full code after adding some records to the teacher section
and check how the interaction goes