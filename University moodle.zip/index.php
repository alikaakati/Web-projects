<?php
header("Location:http://localhost:8012/moodleUSAL/login/login.php");
?>